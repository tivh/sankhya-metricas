<?php $total_sum = 0 ?>
<table>
    <thead>
        <tr style="color: #1820E4;">
            <th>Filial</th>
            <th>Num Nota</th>
            <th>TOP</th>
            <th>Cliente</th>
            <th>Dt. Emissão</th>
            <th>Dt. Validade</th>
            <th>Valor total</th>
            <th>Valor Desdobrado</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $faturamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($fat->cod_emp); ?></td>
            <td><?php echo e($fat->nm_nota); ?></td>
            <td><?php echo e($fat->top); ?></td>
            <td><?php echo e($fat->cliente); ?></td>
            <td><?php echo e($fat->dt_emissao); ?></td>
            <td><?php echo e($fat->dt_val); ?></td>
            <td><?php echo e($fat->vlrnota); ?></td>
            <td><?php echo e($fat->valor_desdobramento); ?></td>
        </tr>
        <?php echo e($total_sum +=  $fat->vlrnota); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td colspan="2">Total: <?php echo e(number_format($total_sum, 2)); ?></td>
            <td></td>
        </tr>
    </tbody>
</table>
<?php /**PATH C:\projetos\sankhya\sankhya-metricas\resources\views/faturamento/faturamento_vendedor.blade.php ENDPATH**/ ?>