<h1>Email teste de envio</h1>
<?php /**PATH C:\projetos\sankhya\sankhya-metricas\resources\views/email/mail_vend.blade.php ENDPATH**/ ?>