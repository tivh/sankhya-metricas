<?php

namespace App\Helpers;

class Utils{

    const MAILS = [
        'junior' => 'jose.junior@vitoriahospitalar.com.br',
        'alexsandra' => 'alexsandra.giaretta@vitoriahospitalar.com.br'
    ];
}
