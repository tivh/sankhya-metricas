<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Vendedor extends Model
{
    use HasFactory;
    protected $table = 'TGFVEN';


    public function getFaturamento($codVendedor)
    {
        $result = DB::select(DB::raw("SELECT
        --CAB2.NUNOTA NM_UNICO,
        CAB2.CODEMP COD_EMP,
        CAB2.NUMNOTA NM_NOTA,
        CAB2.CODTIPOPER TOP,
        PAR.NOMEPARC CLIENTE,
        TO_CHAR(CAB2.DTNEG,'DD/MM/YYYY') DT_EMISSAO,
        TO_CHAR(FIN.DTVENC,'DD/MM/YYYY') DT_VAL,
        VEN.APELIDO VENDEDOR,
        CAB2.VLRNOTA,
        FIN.VLRDESDOB VALOR_DESDOBRAMENTO
        FROM TGFITE ITE2
                    INNER JOIN TGFEST EST2 ON ITE2.CONTROLE = EST2.CONTROLE
                    INNER JOIN TGFCAB CAB2 ON CAB2.NUNOTA = ITE2.NUNOTA
                    INNER JOIN TGFVEN VEN  ON VEN.CODVEND = CAB2.CODVEND
                    INNER JOIN TGFFIN FIN  ON FIN.NUNOTA = CAB2.NUNOTA AND FIN.CODEMP = CAB2.CODEMP
                    INNER JOIN TGFPAR PAR  ON PAR.CODPARC = CAB2.CODPARC
        WHERE
        CAB2.CODTIPOPER IN (1100, 1125)
        AND CAB2.STATUSNFE = 'A'
        AND CAB2.CODVEND = $codVendedor
        GROUP BY FIN.VLRDESDOB, CAB2.STATUSNFE, CAB2.CODEMP, CAB2.DTNEG,CAB2.CODTIPOPER, PAR.NOMEPARC, FIN.DTVENC, CAB2.NUMNOTA, VEN.APELIDO, CAB2.CODVEND ,CAB2.VLRNOTA
        ORDER BY 4
        "));

        return $result;
    }


    public function getVendedores()
    {
        $result = DB::select(DB::raw("SELECT DISTINCT
        VEN.CODVEND,
        VEN.APELIDO
        FROM TGFITE ITE2
                    INNER JOIN TGFEST EST2 ON ITE2.CONTROLE = EST2.CONTROLE
                    INNER JOIN TGFCAB CAB2 ON CAB2.NUNOTA = ITE2.NUNOTA
                    INNER JOIN TGFVEN VEN  ON VEN.CODVEND = CAB2.CODVEND
                    INNER JOIN TGFFIN FIN  ON FIN.NUNOTA = CAB2.NUNOTA AND FIN.CODEMP = CAB2.CODEMP
                    INNER JOIN TGFPAR PAR  ON PAR.CODPARC = CAB2.CODPARC
        WHERE
        CAB2.CODTIPOPER IN (1100, 1125)
        AND CAB2.STATUSNFE = 'A'
        "));

        return $result;
    }
}
